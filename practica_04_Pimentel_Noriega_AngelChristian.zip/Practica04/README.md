Practica 02
Angel Christian Pimentel Noriega

Como ejecutar:
-mvn spring-boot:run
